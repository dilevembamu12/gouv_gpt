/*
Author       : Dreamstechnologies
Template Name: APIX - FintraX - SysOp
*/
(function () {
    "use strict";
	
	// Clipboard 
	if($('.clipboard').length > 0) {
		var clipboard = new Clipboard('.btn');
	}
	
})();