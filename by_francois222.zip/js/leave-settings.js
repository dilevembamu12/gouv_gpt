/*
Author       : Dreamstechnologies
Template Name: APIX - FintraX - SysOp
*/
(function () {
    "use strict";
	
	// Leave Settings
	$('.edit-leave-btn').on('click', function () {
		$(this).parent().parent().parent().toggleClass('show');
	});  
		
})();